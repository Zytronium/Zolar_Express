# Zolar Express

.js

Welcome aboard my test to learn express.js. I need to learn this for two reasons:
T4 at Atlas School will likely introduce me to it, and most importantly, I might
use it in my major personal project, The Faction Nexus. 

This project may end up forking from the News section
of The Faction Nexus. We'll see if it goes that far, but
I doubt it. I like the project name though, ad I can totally
see it being used as a Starscape news network name.

>"Welcome to the Zolar Express, your ticket to all the news in
the Starscape universe!"